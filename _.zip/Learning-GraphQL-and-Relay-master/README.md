## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/learning-graphql-and-relay/9781786465757)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1786465752).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Learning-GraphQL-and-Relay
[Learning GraphQL and Relay](https://www.packtpub.com/web-development/learning-graphql-and-relay?utm_source=GitHub&utm_medium=repository&utm_campaign=9781786465757) by [Packt](https://www.packtpub.com/)

This book does not assume that you have any prior experience or familiarity with GraphQL or Relay. You should, however, be comfortable writing Node.js applications on a MongoDB database with REST APIs as well as applications on the client side using React and ES2015.

You can also refer to the following books:
* [Play Framework Essentials](https://www.packtpub.com/web-development/play-framework-essentials?utm_source=GitHub&utm_medium=repository&utm_campaign=9781783982400)
* [Python Machine Learning Blueprints](https://www.packtpub.com/big-data-and-business-intelligence/python-machine-learning-blueprints-intuitive-data-projects-you-ca?utm_source=GitHub&utm_medium=repository&utm_campaign=9781784394752)
